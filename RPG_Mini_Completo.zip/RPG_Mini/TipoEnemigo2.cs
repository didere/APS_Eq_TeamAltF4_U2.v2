using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    // BERSERKER: daño x2, poca esquiva (0.05), y cuando se "defiende" 
    // carga energía para el siguiente golpe (x3 en vez de x2)
    public class TipoEnemigo2 : Enemigo
    {
        private static Random random = new Random();
        private bool cargando = false; // true cuando usó Defensa para cargar

        public TipoEnemigo2(string nombre, int vida = 60, int ataque = 12, double probEsquivar = 0.05)
            : base(nombre, vida, ataque, probEsquivar) { }

        // Ataca con fuerza doble; si estaba cargando, ataca con fuerza triple
        public override int Atacar(Personaje objetivo)
        {
            bool esquivado = random.NextDouble() < objetivo.ProbEsquivar;
            if (esquivado)
            {
                Console.WriteLine($"{objetivo.Nombre} esquivó el ataque de {Nombre}!");
                cargando = false;
                return 0;
            }

            int multiplicador = cargando ? 3 : 2;
            int dano = Ataque * multiplicador;

            // Si el objetivo se defendió, el daño se reduce a la mitad
            if (objetivo.EstaDefendido)
            {
                dano /= 2;
                Console.WriteLine($"{objetivo.Nombre} bloqueó parte del golpe brutal!");
            }

            objetivo.Vida -= dano;
            objetivo.EstaDefendido = false;

            if (cargando)
                Console.WriteLine($"{Nombre} (Tipo 2) desata FURIA ACUMULADA ({dano} daño x3). " +
                                  $"(Vida restante de {objetivo.Nombre}: {objetivo.Vida})");
            else
                Console.WriteLine($"{Nombre} (Tipo 2) ataca con FUERZA DOBLE ({dano} daño). " +
                                  $"(Vida restante de {objetivo.Nombre}: {objetivo.Vida})");

            cargando = false;
            return dano;
        }

        // El Tipo 2 no bloquea; en cambio carga energía para triplicar su próximo ataque
        public override void Defensa()
        {
            cargando = true;
            Console.WriteLine($"{Nombre} (Tipo 2) acumula furia. ¡Su próximo ataque será TRIPLE!");
        }
    }
}
