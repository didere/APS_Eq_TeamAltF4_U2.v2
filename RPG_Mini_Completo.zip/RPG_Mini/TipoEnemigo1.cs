using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    // ÁGIL: poco daño por golpe, pero esquiva mucho (0.35) y ataca dos veces seguidas
    public class TipoEnemigo1 : Enemigo
    {
        private static Random random = new Random();

        public TipoEnemigo1(string nombre, int vida = 70, int ataque = 20, double probEsquivar = 0.35)
            : base(nombre, vida, ataque, probEsquivar) { }

        // Ataca con golpe reducido (Ataque / 2) pero lo aplica dos veces
        public override int Atacar(Personaje objetivo)
        {
            bool esquivado = random.NextDouble() < objetivo.ProbEsquivar;
            if (esquivado)
            {
                Console.WriteLine($"{objetivo.Nombre} esquivó el ataque de {Nombre}!");
                return 0;
            }

            int danoPorGolpe = Ataque / 2;

            // Si el objetivo se defendió, el daño total se reduce a la mitad
            if (objetivo.EstaDefendido)
            {
                danoPorGolpe /= 2;
                Console.WriteLine($"{objetivo.Nombre} bloqueó parte del ataque doble!");
            }

            int danoTotal = danoPorGolpe * 2;
            objetivo.Vida -= danoTotal;
            objetivo.EstaDefendido = false;

            Console.WriteLine($"{Nombre} (Tipo 1) golpea DOS VECES ({danoPorGolpe} + {danoPorGolpe} = {danoTotal} daño). " +
                              $"(Vida restante de {objetivo.Nombre}: {objetivo.Vida})");
            return danoTotal;
        }

        // El Tipo 1 no se defiende; en cambio, incrementa su probabilidad de esquivar 
        // temporalmente (representa que se vuelve más evasivo)
        public override void Defensa()
        {
            ProbEsquivar = Math.Min(ProbEsquivar + 0.20, 0.90);
            Console.WriteLine($"{Nombre} (Tipo 1) entra en modo evasivo. " +
                              $"Prob. de esquivar sube a {ProbEsquivar:P0}.");
        }
    }
}
