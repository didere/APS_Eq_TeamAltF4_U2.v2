using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    // TANQUE: mucha vida (120), poco ataque (8), esquiva bien (0.50)
    // Su Defensa es la más fuerte: regenera vida además de activar el escudo
    public class TipoEnemigo3 : Enemigo
    {
        private static Random random = new Random();
        private const int RegeneracionDefensa = 10; // vida que recupera al defenderse

        public TipoEnemigo3(string nombre, int vida = 120, int ataque = 8, double probEsquivar = 0.50)
            : base(nombre, vida, ataque, probEsquivar) { }

        // Ataque normal con 30% de probabilidad de golpe crítico (x2)
        public override int Atacar(Personaje objetivo)
        {
            bool esquivado = random.NextDouble() < objetivo.ProbEsquivar;
            if (esquivado)
            {
                Console.WriteLine($"{objetivo.Nombre} esquivó el ataque de {Nombre}!");
                return 0;
            }

            bool critico = random.NextDouble() < 0.30;
            int dano = critico ? Ataque * 2 : Ataque;

            // Si el objetivo se defendió, el daño se reduce a la mitad
            if (objetivo.EstaDefendido)
            {
                dano /= 2;
                Console.WriteLine($"{objetivo.Nombre} bloqueó parte del golpe!");
            }

            objetivo.Vida -= dano;
            objetivo.EstaDefendido = false;

            if (critico)
                Console.WriteLine($"{Nombre} (Tipo 3) lanza un GOLPE CRÍTICO ({dano} daño). " +
                                  $"(Vida restante de {objetivo.Nombre}: {objetivo.Vida})");
            else
                Console.WriteLine($"{Nombre} (Tipo 3) ataca con golpe normal ({dano} daño). " +
                                  $"(Vida restante de {objetivo.Nombre}: {objetivo.Vida})");

            return dano;
        }

        // El Tanque activa escudo Y regenera vida: es el defensor más robusto
        public override void Defensa()
        {
            EstaDefendido = true;
            Vida += RegeneracionDefensa;
            Console.WriteLine($"{Nombre} (Tipo 3) levanta su escudo y se regenera {RegeneracionDefensa} de vida. " +
                              $"(Vida actual: {Vida}). El próximo golpe causará la mitad de daño.");
        }
    }
}
