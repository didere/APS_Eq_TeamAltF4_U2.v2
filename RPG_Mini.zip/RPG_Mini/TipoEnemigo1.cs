﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    public class TipoEnemigo1 : Enemigo
    {
        private static Random random = new Random();

        public TipoEnemigo1(string nombre, int vida = 70, int ataque = 20, double probEsquivar = 0.35)
            : base(nombre, vida, ataque, probEsquivar) { }

        public override int Atacar(Personaje objetivo)
        {
            bool esquivado = random.NextDouble() < objetivo.ProbEsquivar;
            if (esquivado)
            {
                Console.WriteLine($"{objetivo.Nombre} esquivó el ataque de {Nombre}!");
                return 0;
            }

            int dano = Ataque / 2;   // loAtaque / 2
            objetivo.Vida -= dano;
            Console.WriteLine($"{Nombre} (Tipo 1) ataca con golpe reducido ({dano} daño). " +
                              $"(Vida restante de {objetivo.Nombre}: {objetivo.Vida})");
            return dano;
        }

        public override void Defensa()
        {
          
        }
    }
}
