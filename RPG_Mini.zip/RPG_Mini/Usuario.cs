﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    public class Usuario : Personaje
    {
        public Usuario(string nombre, int vida = 100, int ataque = 15, double probEsquivar = 0.20)
            : base(nombre, vida, ataque, probEsquivar) { }

        public override int Atacar(Personaje objetivo)
        {
            
        }

        public override 
    }
}
