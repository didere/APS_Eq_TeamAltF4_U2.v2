﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    public class TipoEnemigo3 : Enemigo
    {
        private bool defensa = false;

        public TipoEnemigo3(string nombre, int vida = 120, int ataque = 8, double probEsquivar = 0.50)
            : base(nombre, vida, ataque, probEsquivar) { }

        public override string Defensa()
        {
            
        }

        public override int Atacar(int dano)
        {
           
        }
    }
}
