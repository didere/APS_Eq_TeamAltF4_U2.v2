using System;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    public class Personaje
    {
        private string nombre;
        private int vida;
        private int vidaMaxima;
        private int ataque;
        private double probEsquivar;
        protected bool estaDefendiendo;

        public string Nombre       { get { return nombre; }       set { nombre = value; } }
        public int Vida            { get { return vida; }         set { vida = Math.Max(0, value); } }
        public int VidaMaxima      { get { return vidaMaxima; }   set { vidaMaxima = value; } }
        public int Ataque          { get { return ataque; }       set { ataque = value; } }
        public double ProbEsquivar { get { return probEsquivar; } set { probEsquivar = value; } }
        public bool EstaDefendiendo => estaDefendiendo;
        public bool EstaVivo        => Vida > 0;

        protected static Random random = new Random();

        public Personaje(string nombre, int vida, int ataque, double probEsquivar)
        {
            Nombre          = nombre;
            VidaMaxima      = vida;
            Vida            = vida;
            Ataque          = ataque;
            ProbEsquivar    = probEsquivar;
            estaDefendiendo = false;
        }

        // Ataca al objetivo. Devuelve el daño causado (0 si esquivó o bloqueó todo).
        public virtual int Atacar(Personaje objetivo)
        {
            if (random.NextDouble() < objetivo.ProbEsquivar)
            {
                Console.WriteLine($"  💨 {objetivo.Nombre} esquivó el ataque de {Nombre}!");
                return 0;
            }

            int dano = Ataque;

            if (objetivo.estaDefendiendo)
            {
                dano = (int)(dano * 0.5);
                Console.WriteLine($"  🛡️  {objetivo.Nombre} bloqueó parte del golpe! ({Nombre} causó solo {dano} de daño)");
            }
            else
            {
                Console.WriteLine($"  ⚔️  {Nombre} ataca a {objetivo.Nombre} causando {dano} de daño.");
            }

            objetivo.Vida -= dano;
            Console.WriteLine($"     ❤️  Vida de {objetivo.Nombre}: {objetivo.Vida}/{objetivo.VidaMaxima}");
            return dano;
        }

        // Activa la postura defensiva para reducir el daño recibido este turno a la mitad.
        public virtual void Defensa()
        {
            estaDefendiendo = true;
            Console.WriteLine($"  🛡️  {Nombre} adopta postura defensiva!");
        }

        // Reinicia la bandera de defensa al inicio de cada nuevo turno.
        public void ResetDefensa() => estaDefendiendo = false;

        public override string ToString()
            => $"{Nombre} | ❤️ {Vida}/{VidaMaxima} | ⚔️ {Ataque} | 💨 Esquive {ProbEsquivar * 100:0}%";
    }
}
