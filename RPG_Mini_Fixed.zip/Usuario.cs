using System;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    public class Usuario : Personaje
    {
        // Probabilidad base de crítico (10%). Sube 5% por cada enemigo derrotado.
        private double probCritico;

        public Usuario(string nombre, int vida = 100, int ataque = 15, double probEsquivar = 0.20)
            : base(nombre, vida, ataque, probEsquivar)
        {
            probCritico = 0.10;
        }

        // Aumenta la prob. de crítico al derrotar un enemigo (máx. 50%).
        public void RegistrarVictoria()
        {
            probCritico = Math.Min(probCritico + 0.05, 0.50);
            Console.WriteLine($"  ⭐ ¡Golpe crítico mejorado! Probabilidad actual: {probCritico * 100:0}%");
        }

        // Ataque del usuario: puede hacer un crítico (daño x2).
        public override int Atacar(Personaje objetivo)
        {
            if (random.NextDouble() < objetivo.ProbEsquivar)
            {
                Console.WriteLine($"  💨 {objetivo.Nombre} esquivó el ataque de {Nombre}!");
                return 0;
            }

            int dano = Ataque;
            bool esCritico = random.NextDouble() < probCritico;

            if (esCritico)
            {
                dano *= 2;
                Console.WriteLine($"  💥 ¡GOLPE CRÍTICO! {Nombre} ataca a {objetivo.Nombre} con {dano} de daño.");
            }
            else
            {
                Console.WriteLine($"  ⚔️  {Nombre} ataca a {objetivo.Nombre} causando {dano} de daño.");
            }

            if (objetivo.EstaDefendiendo)
            {
                dano = (int)(dano * 0.5);
                Console.WriteLine($"     🛡️  ¡{objetivo.Nombre} bloqueó parte! Daño real: {dano}");
            }

            objetivo.Vida -= dano;
            Console.WriteLine($"     ❤️  Vida de {objetivo.Nombre}: {objetivo.Vida}/{objetivo.VidaMaxima}");
            return dano;
        }

        // El usuario se defiende: reduce el daño recibido a la mitad en el próximo ataque enemigo.
        public override void Defensa()
        {
            estaDefendiendo = true;
            Console.WriteLine($"  🛡️  {Nombre} se pone en guardia para reducir el próximo golpe!");
        }
    }
}
