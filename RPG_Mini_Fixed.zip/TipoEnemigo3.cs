using System;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    // TipoEnemigo3 — "Guardián"
    // Vida: 120 | Ataque: 8 | Esquive: 50%
    // Especialidad: altísima supervivencia. Se defiende frecuentemente y contraataca con espinas.
    public class TipoEnemigo3 : Enemigo
    {
        // Daño de reflejo que devuelve al atacante cuando el Guardián está en modo defensa.
        private const int DANO_REFLEJO = 5;

        public TipoEnemigo3(string nombre, int vida = 120, int ataque = 8, double probEsquivar = 0.50)
            : base(nombre, vida, ataque, probEsquivar) { }

        // Ataque del guardián: daño base bajo, pero si el objetivo está defendiéndose
        // el Guardián aprovecha para dar un golpe más preciso (ignora la mitad de la reducción).
        public override int Atacar(Personaje objetivo)
        {
            if (random.NextDouble() < objetivo.ProbEsquivar)
            {
                Console.WriteLine($"  💨 {objetivo.Nombre} esquivó el ataque de {Nombre}!");
                return 0;
            }

            int dano = Ataque;

            if (objetivo.EstaDefendiendo)
            {
                // Solo reduce al 75% en lugar del 50% habitual: el Guardián busca los huecos.
                dano = (int)(dano * 0.75);
                Console.WriteLine($"  🗡️  {Nombre} [Guardián] ataca buscando el hueco de tu escudo: {dano} de daño.");
            }
            else
            {
                Console.WriteLine($"  🗡️  {Nombre} [Guardián] golpea lentamente: {dano} de daño.");
            }

            objetivo.Vida -= dano;
            Console.WriteLine($"     ❤️  Vida de {objetivo.Nombre}: {objetivo.Vida}/{objetivo.VidaMaxima}");
            return dano;
        }

        // Defensa con reflejo: adopta postura y devuelve daño al próximo atacante.
        public override void Defensa()
        {
            estaDefendiendo = true;
            Console.WriteLine($"  🛡️✨ {Nombre} [Guardián] levanta su escudo con espinas " +
                              $"(refleja {DANO_REFLEJO} de daño al próximo atacante)!");
        }

        // Método que aplica el reflejo cuando alguien ataca al Guardián mientras se defiende.
        public void AplicarReflejo(Personaje atacante)
        {
            if (estaDefendiendo && atacante.EstaVivo)
            {
                atacante.Vida -= DANO_REFLEJO;
                Console.WriteLine($"  🌀 ¡Las espinas del escudo de {Nombre} devuelven " +
                                  $"{DANO_REFLEJO} de daño a {atacante.Nombre}! " +
                                  $"(Vida: {atacante.Vida}/{atacante.VidaMaxima})");
            }
        }

        // IA: el Guardián se defiende el 50% del tiempo (su identidad es la resistencia).
        public override void TurnoIA(Personaje objetivo)
        {
            ResetDefensa();

            if (random.NextDouble() < 0.50)
                Defensa();
            else
                Atacar(objetivo);
        }
    }
}
