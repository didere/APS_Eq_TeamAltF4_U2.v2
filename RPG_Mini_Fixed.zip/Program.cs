using System;
using System.Collections.Generic;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("╔══════════════════════════════╗");
            Console.WriteLine("║       RPG MINI — Inicio      ║");
            Console.WriteLine("╚══════════════════════════════╝\n");

            Console.Write("Ingresa el nombre de tu personaje: ");
            string nombreJugador = Console.ReadLine() ?? "Héroe";

            Usuario jugador = new Usuario(nombreJugador);
            Console.WriteLine($"\n✅ Bienvenido, {jugador}\n");

            // Pool de posibles enemigos
            List<Enemigo> pool = new List<Enemigo>
            {
                new TipoEnemigo1("Explorador Sombra"),
                new TipoEnemigo2("Berserker Rojo"),
                new TipoEnemigo3("Guardián Antiguo"),
                new TipoEnemigo1("Espía Veloz"),
                new TipoEnemigo2("Ogro Furioso"),
                new TipoEnemigo3("Centinela Eterno"),
            };

            Random rng = new Random();
            int enemigosDerrotados = 0;

            while (jugador.EstaVivo && pool.Count > 0)
            {
                // Seleccionar enemigo aleatorio del pool
                int idx = rng.Next(pool.Count);
                Enemigo enemigo = pool[idx];
                pool.RemoveAt(idx);

                Console.WriteLine("\n" + new string('═', 40));
                Console.WriteLine($"  ⚠️  ¡Aparece un {enemigo.Nombre}!");
                Console.WriteLine($"  {enemigo}");
                Console.WriteLine(new string('═', 40));

                // --- Bucle de combate ---
                while (jugador.EstaVivo && enemigo.EstaVivo)
                {
                    Console.WriteLine($"\n[Turno] {jugador.Nombre}: ❤️ {jugador.Vida} | {enemigo.Nombre}: ❤️ {enemigo.Vida}");
                    Console.WriteLine("  ¿Qué haces? [A] Atacar   [D] Defenderte");
                    string accion = (Console.ReadLine() ?? "A").Trim().ToUpper();

                    jugador.ResetDefensa();

                    if (accion == "D")
                    {
                        jugador.Defensa();
                    }
                    else
                    {
                        // Si el enemigo es un Guardián en defensa, aplicar reflejo
                        if (enemigo is TipoEnemigo3 guardian && guardian.EstaDefendiendo)
                        {
                            jugador.Atacar(enemigo);
                            guardian.AplicarReflejo(jugador);
                        }
                        else
                        {
                            jugador.Atacar(enemigo);
                        }
                    }

                    if (!enemigo.EstaVivo) break;

                    // Turno del enemigo
                    Console.WriteLine($"\n  [{enemigo.Nombre}] contraataca...");
                    enemigo.TurnoIA(jugador);
                }

                if (enemigo.EstaVivo == false)
                {
                    enemigosDerrotados++;
                    Console.WriteLine($"\n  🏆 ¡Derrotaste a {enemigo.Nombre}! (Victorias: {enemigosDerrotados})");
                    jugador.RegistrarVictoria();

                    // Curación parcial entre combates (25% de la vida máxima)
                    if (jugador.EstaVivo && pool.Count > 0)
                    {
                        int curacion = jugador.VidaMaxima / 4;
                        jugador.Vida = Math.Min(jugador.Vida + curacion, jugador.VidaMaxima);
                        Console.WriteLine($"  💊 Descansas y recuperas {curacion} de vida. " +
                                          $"Vida actual: {jugador.Vida}/{jugador.VidaMaxima}");
                    }
                }
            }

            Console.WriteLine("\n" + new string('═', 40));
            if (jugador.EstaVivo)
            {
                Console.WriteLine($"  🎉 ¡{jugador.Nombre} venció a todos los enemigos con {jugador.Vida} HP restantes!");
                Console.WriteLine($"  Enemigos derrotados: {enemigosDerrotados}");
            }
            else
            {
                Console.WriteLine($"  💀 {jugador.Nombre} cayó en batalla tras derrotar {enemigosDerrotados} enemigo(s).");
                Console.WriteLine("  Mejor suerte la próxima vez...");
            }
            Console.WriteLine(new string('═', 40));
        }
    }
}
