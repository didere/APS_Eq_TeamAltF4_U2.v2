using System;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    // TipoEnemigo2 — "Berserker"
    // Vida: 60 | Ataque: 12 (x2 = 24 efectivo) | Esquive: 5%
    // Especialidad: daño devastador, nunca se defiende — pura ofensiva.
    public class TipoEnemigo2 : Enemigo
    {
        private int turnosConsecutivosAtacando;

        public TipoEnemigo2(string nombre, int vida = 60, int ataque = 12, double probEsquivar = 0.05)
            : base(nombre, vida, ataque, probEsquivar)
        {
            turnosConsecutivosAtacando = 0;
        }

        // Ataque berserker: daño doble. Cada 3 ataques consecutivos lanza un golpe devastador (x3).
        public override int Atacar(Personaje objetivo)
        {
            if (random.NextDouble() < objetivo.ProbEsquivar)
            {
                Console.WriteLine($"  💨 {objetivo.Nombre} esquivó el ataque de {Nombre}!");
                turnosConsecutivosAtacando = 0;
                return 0;
            }

            turnosConsecutivosAtacando++;
            int multiplicador = (turnosConsecutivosAtacando % 3 == 0) ? 3 : 2;
            int dano = Ataque * multiplicador;

            if (objetivo.EstaDefendiendo)
            {
                dano = (int)(dano * 0.5);
                Console.WriteLine($"  🛡️  {objetivo.Nombre} aguantó el embate! Daño reducido a {dano}.");
            }

            string etiqueta = multiplicador == 3 ? "🌪️ [DEVASTADOR]" : "💢 [Berserker]";
            objetivo.Vida -= dano;

            Console.WriteLine($"  {etiqueta} {Nombre} golpea con furia: {dano} de daño.");
            Console.WriteLine($"     ❤️  Vida de {objetivo.Nombre}: {objetivo.Vida}/{objetivo.VidaMaxima}");
            return dano;
        }

        // El berserker nunca se defiende — si la IA intenta defenderse, ataca igualmente.
        public override void Defensa()
        {
            Console.WriteLine($"  💢 {Nombre} [Berserker] ¡no conoce la defensa! Sigue atacando.");
        }

        public override void TurnoIA(Personaje objetivo)
        {
            ResetDefensa();
            // El berserker SIEMPRE ataca, nunca se defiende.
            Atacar(objetivo);
        }
    }
}
