using System;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    /*
     * Jerarquía de enemigos:
     *
     *   Enemigo (base)
     *   ├── TipoEnemigo1 : Rápido y esquivo  — vida baja, ataque reducido (mitad), esquive alto (35%)
     *   ├── TipoEnemigo2 : Tanque berserker  — vida media, ataque doble, casi sin esquive (5%)
     *   └── TipoEnemigo3 : Guardián          — vida alta, ataque bajo, esquive muy alto (50%) + bloqueo activo
     *
     * Mecánica de turno:
     *   1. Jugador elige: [A]tacar o [D]efenderse.
     *   2. Si el jugador atacó, el enemigo puede recibir el daño, bloquearlo (Defensa) o esquivarlo.
     *   3. El enemigo contraataca; si el jugador se defendió previamente, recibe la mitad del daño.
     *   4. Se repite hasta que uno de los dos llegue a 0 de vida.
     */
    public class Enemigo : Personaje
    {
        public Enemigo(string nombre, int vida = 80, int ataque = 10, double probEsquivar = 0.10)
            : base(nombre, vida, ataque, probEsquivar) { }

        // Los enemigos eligen defender aleatoriamente con 20% de probabilidad.
        public virtual void TurnoIA(Personaje objetivo)
        {
            ResetDefensa();

            if (random.NextDouble() < 0.20)
                Defensa();
            else
                Atacar(objetivo);
        }
    }
}
