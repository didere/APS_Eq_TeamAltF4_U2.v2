using System;

namespace APS_Eq_TeamAltF4_U2.v2.RPG_Mini
{
    // TipoEnemigo1 — "Explorador Ágil"
    // Vida: 70 | Ataque: 20 (reducido a la mitad = 10 efectivo) | Esquive: 35%
    // Especialidad: muy difícil de golpear, pero sus ataques son débiles.
    public class TipoEnemigo1 : Enemigo
    {
        public TipoEnemigo1(string nombre, int vida = 70, int ataque = 20, double probEsquivar = 0.35)
            : base(nombre, vida, ataque, probEsquivar) { }

        // Ataque ágil: siempre hace la mitad del daño base, pero ignora la defensa del objetivo.
        public override int Atacar(Personaje objetivo)
        {
            if (random.NextDouble() < objetivo.ProbEsquivar)
            {
                Console.WriteLine($"  💨 {objetivo.Nombre} esquivó el ataque de {Nombre}!");
                return 0;
            }

            // Golpe rápido: mitad de daño pero penetra la defensa (ignora el bloqueo).
            int dano = Ataque / 2;
            objetivo.Vida -= dano;

            string extraMsg = objetivo.EstaDefendiendo
                ? " (¡el golpe ágil penetró tu defensa!)"
                : "";

            Console.WriteLine($"  🗡️  {Nombre} [Ágil] lanza un golpe rápido: {dano} de daño{extraMsg}.");
            Console.WriteLine($"     ❤️  Vida de {objetivo.Nombre}: {objetivo.Vida}/{objetivo.VidaMaxima}");
            return dano;
        }

        // El explorador se lanza al suelo para esquivar: aumenta temporalmente su probabilidad de esquive.
        public override void Defensa()
        {
            estaDefendiendo = true;
            double bonoEsquive = 0.15;
            ProbEsquivar = Math.Min(ProbEsquivar + bonoEsquive, 0.85);
            Console.WriteLine($"  💨 {Nombre} [Ágil] se lanza al suelo y aumenta su esquive temporalmente " +
                              $"({ProbEsquivar * 100:0}%)!");
        }

        public override void TurnoIA(Personaje objetivo)
        {
            // Restaura el esquive al valor base antes del turno.
            ProbEsquivar = 0.35;
            ResetDefensa();

            // 30% de chance de esquivar/defender en lugar de atacar.
            if (random.NextDouble() < 0.30)
                Defensa();
            else
                Atacar(objetivo);
        }
    }
}
